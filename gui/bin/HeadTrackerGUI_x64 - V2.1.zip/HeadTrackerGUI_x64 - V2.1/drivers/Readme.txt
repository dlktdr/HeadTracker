Notes on the additional items in this folder
--------------------------------------------

dpinst-amd64.exe
    Install this if you are running windows 7 or 8 it contains the BLE drivers. 
    Windows 10 users do not need to install this

vc_redist.x64.exe
    If you get the Error "TLS Initalization Failed" please install this package from 
    Microsoft is contains support software needed by the OpenSSL. Which allows this 
    program to download from the secure github server.