Please see the drivers folder for additional items

Most recent firmware at the time of this writing is included in the firmwares folder. 
You can install it by choosing Upload Local in the uploader window